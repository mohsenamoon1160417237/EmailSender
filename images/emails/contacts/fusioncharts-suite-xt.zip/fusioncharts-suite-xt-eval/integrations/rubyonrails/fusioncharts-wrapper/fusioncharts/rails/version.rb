module Fusioncharts
  module Rails
    VERSION = "0.0.2"
  end
end
