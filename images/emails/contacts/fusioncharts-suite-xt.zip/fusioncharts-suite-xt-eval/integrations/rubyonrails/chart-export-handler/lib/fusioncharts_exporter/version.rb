module FusionchartsExporter
  VERSION = "0.0.1"
end
